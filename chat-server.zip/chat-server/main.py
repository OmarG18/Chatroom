from flask import Flask, render_template, request, session, redirect, url_for
from flask_socketio import join_room, leave_room, send, SocketIO
import random
from string import ascii_uppercase


app = Flask(__name__)
app.config["SECRET_KEY"] = "1e31e1"
socketio = SocketIO(app)

rooms = {}

def generate_unique_code(length):
    while True:
        code = ""

        for _ in range(length):
            code += random.choice(ascii_uppercase ) #will generate a random 4 charecter key that is made by ascii when the function is called
        if code not in rooms: #if the room doesnt exist in the dictionary STOP
            break
    return code #if room does exist return the key code and generate a new one

#works like commands in video games with "/"
@app.route("/", methods=["POST", "GET"])
def home():
    session.clear() #would make user go back to the homepage instead of doing a /home command
    if request.method == "POST":
        #form is a type of python dictionary and .get is looking for the item in said dictionary which is safer since there will be 
        #times where an item does not exist in the dictionary and .get would return nothing if that happens(better than an error/crash)
        name = request.form.get("name")
        code = request.form.get("code")
        join = request.form.get("join", False) #since these two are buttons they return boolean values 
        create = request.form.get("create", False)

        if not name: #this means, if usere enters nothing do this
            return render_template("home.html", error="please enter a name", code=code, name=name)
    
        if join != False and not code:
            return render_template("home.html", error="please enter a room code", code=code, name=name)

        room = code
        if create != False: #if not make a room they try joining a room
            room = generate_unique_code(4)
            #messages is a list that will add new user messages to said list 
            rooms[room] = {"members": 0, "messages": []}
        elif code not in rooms: #if room doesnt exist return error
            return render_template("home.html", error="room does not exist", code=code, name=name)

        session["room"] = room
        session["name"] = name
        return redirect(url_for("room"))
    return render_template("home.html")

@app.route("/room")
def room():
    room = session.get("room")
    if room is None or session.get("name") is None or room not in rooms:
        return redirect(url_for("home"))

    return render_template("room.html", code=room)

# gets the message user sent and sends the message to everyone thorugh the server 
@socketio.on("message")
def message(data):
    room = session.get("room")
    if room not in rooms:
        return
    content = {
        "name": session.get("name"),
        "message": data["data"]
    }
    send(content, to=room)
    rooms[room]["messages"].append(content)
    print(f"{session.get('name')} said {data['data']}")

# code for entering a chat room

@socketio.on("connect")
def connect(auth):
    room = session.get("room") #getting the name from the user
    name = session.get("name") #getting the room code from the user
    #checks if they do have a room or a name 
    if not room or not name:
        return
    #checks if the room they entered exists if not it makes them leave 
    if room not in rooms:
        leave_room(room)
        return
    
    #runs if the user passes all of the other if statements 
    join_room(room)
    send({"name": name, "message": "has entered the room"}, to=room)
    #keeps track of the users inside a room
    rooms[room]["members"] += 1
    #does what it says but can be used to test create room and join room
    print(f"{name} entered room {room}")

# code for leaving the chat room
@socketio.on("disconnect")
def disconnect():
    room = session.get("room")
    name = session.get("name")
    leave_room(room)

    if room in rooms:
        rooms[room]["members"] -= 1
        if rooms [room]["members"] <= 0: # if there are no people inside the room delete the room 
            del rooms[room]
        send({"name": name, "message": "has left the room"}, to=room)
        print(f"{name} has left the room {room}")



if __name__ == "__main__":
    socketio.run(app, debug=True) #automatically refresh any changes without restarting server 